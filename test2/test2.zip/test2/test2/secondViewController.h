//
//  secondViewController.h
//  test2
//
//  Created by baidu on 16/6/30.
//  Copyright © 2016年 baidu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface secondViewController : UIViewController
@property(nonatomic,strong)UIWindow *window;
@end
