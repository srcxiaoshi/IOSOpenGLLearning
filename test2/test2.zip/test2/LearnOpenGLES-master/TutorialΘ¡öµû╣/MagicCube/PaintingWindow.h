
#import <UIKit/UIKit.h>

@interface PaintingWindow : UIWindow {

}

@end
