这个为修改版

[原地址](https://github.com/yinghuochong/MagicCube)