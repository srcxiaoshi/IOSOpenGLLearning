//
//  ParseOBJ.hpp
//  LearnBlender2OpenGLES
//
//  Created by 林伟池 on 16/4/20.
//  Copyright © 2016年 林伟池. All rights reserved.
//

#ifndef ParseOBJ_hpp
#define ParseOBJ_hpp

#include <iostream>
#include <fstream>
#include <string>
using namespace::std;

#endif /* ParseOBJ_hpp */
