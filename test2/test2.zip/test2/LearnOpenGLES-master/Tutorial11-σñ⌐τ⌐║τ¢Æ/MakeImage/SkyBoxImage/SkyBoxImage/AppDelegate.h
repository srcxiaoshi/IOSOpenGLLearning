//
//  AppDelegate.h
//  SkyBoxImage
//
//  Created by 林伟池 on 16/4/27.
//  Copyright © 2016年 林伟池. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

