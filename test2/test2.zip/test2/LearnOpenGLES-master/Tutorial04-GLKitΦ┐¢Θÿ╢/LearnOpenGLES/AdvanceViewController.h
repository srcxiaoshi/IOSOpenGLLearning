//
//  AdvanceViewController.h
//  LearnOpenGLES
//
//  Created by 林伟池 on 16/3/25.
//  Copyright © 2016年 林伟池. All rights reserved.
//

#import <GLKit/GLKit.h>

@interface AdvanceViewController : GLKViewController

@end
